// mhmd2.ma71@gmail.com
#include "SquareMat.hpp"
#include <iostream>
#include <stdexcept>

namespace mat {

SquareMat::SquareMat(int size) : size_(size), data(new int[size * size]{}) {}

SquareMat::~SquareMat() {
    delete[] data;
}

SquareMat::SquareMat(const SquareMat& other) : size_(other.size_), data(new int[other.size_ * other.size_]) {
    for (int i = 0; i < size_ * size_; ++i)
        data[i] = other.data[i];
}

SquareMat& SquareMat::operator=(const SquareMat& other) {
    if (this != &other) {
        if (size_ != other.size_) {
            delete[] data;
            size_ = other.size_;
            data = new int[size_ * size_];
        }
        for (int i = 0; i < size_ * size_; ++i)
            data[i] = other.data[i];
    }
    return *this;
}

int SquareMat::index(int i, int j) const {
    if (i < 0 || j < 0 || i >= size_ || j >= size_)
        throw std::out_of_range("Index out of range");
    return i * size_ + j;
}

int& SquareMat::operator()(int i, int j) {
    return data[index(i, j)];
}

int SquareMat::operator()(int i, int j) const {
    return data[index(i, j)];
}

SquareMat SquareMat::operator+(const SquareMat& other) const {
    SquareMat result(size_);
    for (int i = 0; i < size_ * size_; ++i)
        result.data[i] = data[i] + other.data[i];
    return result;
}

SquareMat SquareMat::operator-(const SquareMat& other) const {
    SquareMat result(size_);
    for (int i = 0; i < size_ * size_; ++i)
        result.data[i] = data[i] - other.data[i];
    return result;
}

SquareMat SquareMat::operator*(const SquareMat& other) const {
    SquareMat result(size_);
    for (int i = 0; i < size_; ++i)
        for (int j = 0; j < size_; ++j) {
            result(i, j) = 0;
            for (int k = 0; k < size_; ++k)
                result(i, j) += (*this)(i, k) * other(k, j);
        }
    return result;
}

SquareMat& SquareMat::operator+=(const SquareMat& other) {
    return *this = *this + other;
}

SquareMat& SquareMat::operator-=(const SquareMat& other) {
    return *this = *this - other;
}

SquareMat& SquareMat::operator*=(const SquareMat& other) {
    return *this = *this * other;
}

bool SquareMat::operator==(const SquareMat& other) const {
    for (int i = 0; i < size_ * size_; ++i)
        if (data[i] != other.data[i]) return false;
    return true;
}

bool SquareMat::operator!=(const SquareMat& other) const {
    return !(*this == other);
}

SquareMat& SquareMat::operator++() {
    for (int i = 0; i < size_ * size_; ++i)
        ++data[i];
    return *this;
}

SquareMat SquareMat::operator++(int) {
    SquareMat temp(*this);
    ++(*this);
    return temp;
}

SquareMat& SquareMat::operator--() {
    for (int i = 0; i < size_ * size_; ++i)
        --data[i];
    return *this;
}

SquareMat SquareMat::operator--(int) {
    SquareMat temp(*this);
    --(*this);
    return temp;
}

SquareMat SquareMat::operator-() const {
    SquareMat result(size_);
    for (int i = 0; i < size_ * size_; ++i)
        result.data[i] = -data[i];
    return result;
}

int SquareMat::getSize() const {
    return size_;
}

int SquareMat::get(int i, int j) const {
    return (*this)(i, j);
}

void SquareMat::set(int i, int j, int value) {
    (*this)(i, j) = value;
}

void SquareMat::identity() {
    for (int i = 0; i < size_; ++i)
        for (int j = 0; j < size_; ++j)
            (*this)(i, j) = (i == j) ? 1 : 0;
}

void SquareMat::transpose() {
    for (int i = 0; i < size_; ++i)
        for (int j = i + 1; j < size_; ++j) {
            int temp = (*this)(i, j);
            (*this)(i, j) = (*this)(j, i);
            (*this)(j, i) = temp;
        }
}

std::ostream& operator<<(std::ostream& os, const SquareMat& mat) {
    for (int i = 0; i < mat.getSize(); ++i) {
        for (int j = 0; j < mat.getSize(); ++j)
            os << mat.get(i, j) << " ";
        os << "\n";
    }
    return os;
}

std::istream& operator>>(std::istream& is, SquareMat& mat) {
    for (int i = 0; i < mat.getSize(); ++i)
        for (int j = 0; j < mat.getSize(); ++j) {
            int val;
            is >> val;
            mat.set(i, j, val);
        }
    return is;
}

} // namespace mat

