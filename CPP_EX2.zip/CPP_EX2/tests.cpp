// mhmd2.ma71@gmail.com
#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"
#include "SquareMat.hpp"

using namespace mat;

TEST_CASE("Constructor and getSize") {
    SquareMat m(5);
    CHECK(m.getSize() == 5);
}

TEST_CASE("Set and Get Elements") {
    SquareMat m(3);
    m.set(0, 0, 5);
    m.set(1, 2, 7);
    m.set(2, 1, 3);
    CHECK(m.get(0, 0) == 5);
    CHECK(m.get(1, 2) == 7);
    CHECK(m.get(2, 1) == 3);
    CHECK(m.get(2, 2) == 0);
}

TEST_CASE("Matrix Addition and Subtraction") {
    SquareMat a(2);
    SquareMat b(2);
    a.set(0, 0, 1);
    a.set(0, 1, 2);
    b.set(0, 0, 3);
    b.set(0, 1, 4);
    SquareMat c = a + b;
    SquareMat d = b - a;
    CHECK(c.get(0, 0) == 4);
    CHECK(c.get(0, 1) == 6);
    CHECK(d.get(0, 0) == 2);
    CHECK(d.get(0, 1) == 2);
}

TEST_CASE("Matrix Multiplication") {
    SquareMat a(2);
    SquareMat b(2);
    a.set(0, 0, 1);
    a.set(0, 1, 2);
    a.set(1, 0, 3);
    a.set(1, 1, 4);
    b.set(0, 0, 2);
    b.set(0, 1, 0);
    b.set(1, 0, 1);
    b.set(1, 1, 2);
    SquareMat c = a * b;
    CHECK(c.get(0, 0) == 4);
    CHECK(c.get(0, 1) == 4);
    CHECK(c.get(1, 0) == 10);
    CHECK(c.get(1, 1) == 8);
}

TEST_CASE("Matrix Comparison Operators") {
    SquareMat a(2);
    SquareMat b(2);
    a.set(0, 0, 1);
    a.set(0, 1, 2);
    b.set(0, 0, 1);
    b.set(0, 1, 2);
    CHECK(a == b);
    b.set(1, 1, 1);
    CHECK(a != b);
}

TEST_CASE("Matrix Transpose") {
    SquareMat m(2);
    m.set(0, 1, 5);
    m.set(1, 0, 7);
    m.transpose();
    CHECK(m.get(1, 0) == 5);
    CHECK(m.get(0, 1) == 7);
}

TEST_CASE("Matrix Identity") {
    SquareMat m(3);
    m.identity();
    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
            if (i == j) CHECK(m.get(i, j) == 1);
            else CHECK(m.get(i, j) == 0);
        }
    }
}

TEST_CASE("Matrix Negation") {
    SquareMat m(2);
    m.set(0, 0, 2);
    m.set(1, 1, -3);
    SquareMat neg = -m;
    CHECK(neg.get(0, 0) == -2);
    CHECK(neg.get(1, 1) == 3);
}

TEST_CASE("Edge cases: Zero matrix and self operations") {
    SquareMat zero(2);
    SquareMat a(2);
    a.set(0, 0, 5);
    SquareMat b = a + zero;
    SquareMat c = a - zero;
    CHECK(b == a);
    CHECK(c == a);
}
// Edge case: 1x1 matrix
TEST_CASE("1x1 matrix operations") {
    mat::SquareMat A(1);
    mat::SquareMat B(1);
    A.set(0, 0, 3);
    B.set(0, 0, 5);

    DOCTEST_CHECK((A + B)(0, 0) == 8);
    DOCTEST_CHECK((A - B)(0, 0) == -2);
    DOCTEST_CHECK((A * B)(0, 0) == 15);

    ++A;
    DOCTEST_CHECK(A(0, 0) == 4);
    A--;
    DOCTEST_CHECK(A(0, 0) == 3);
}

// Edge case: Identity matrix multiplication
TEST_CASE("Multiplication with identity matrix") {
    mat::SquareMat I(3);
    I.identity();

    mat::SquareMat A(3);
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
            A.set(i, j, i + j);

    mat::SquareMat result = A * I;
    DOCTEST_CHECK(result == A);
}

// Edge case: transpose of identity is same
TEST_CASE("Transpose of identity matrix") {
    mat::SquareMat I(4);
    I.identity();
    I.transpose();
    for (int i = 0; i < 4; ++i)
        for (int j = 0; j < 4; ++j)
            DOCTEST_CHECK(I(i, j) == (i == j ? 1 : 0));
}

// Edge case: negative values
TEST_CASE("Negative values matrix") {
    mat::SquareMat A(2);
    A.set(0, 0, -1);
    A.set(0, 1, -2);
    A.set(1, 0, -3);
    A.set(1, 1, -4);

    mat::SquareMat B = -A;
    DOCTEST_CHECK(B(0, 0) == 1);
    DOCTEST_CHECK(B(1, 1) == 4);
}

// Edge case: exception for invalid access
TEST_CASE("Out of range access throws") {
    mat::SquareMat A(2);
    bool threw = false;
    try {
        A.get(3, 3);
    } catch (const std::out_of_range&) {
        threw = true;
    }
    DOCTEST_CHECK(threw);
}


