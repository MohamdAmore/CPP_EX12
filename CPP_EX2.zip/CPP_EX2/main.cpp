// mhmd2.ma71@gmail.com
#include "SquareMat.hpp"
#include <iostream>

using mat::SquareMat;

int main() {
    // Create two 3x3 matrices
    SquareMat A(3), B(3);

    // Fill A and B with sample values
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j) {
            A.set(i, j, i + j);
            B.set(i, j, i * j);
        }

    // Display A and B
    std::cout << "Matrix A:\n" << A;
    std::cout << "Matrix B:\n" << B;

    // Arithmetic operations
    SquareMat C = A + B;
    std::cout << "A + B:\n" << C;

    SquareMat D = A - B;
    std::cout << "A - B:\n" << D;

    SquareMat E = A * B;
    std::cout << "A * B:\n" << E;

    // Compound assignments
    C += A;
    std::cout << "C += A:\n" << C;

    D -= B;
    std::cout << "D -= B:\n" << D;

    E *= A;
    std::cout << "E *= A:\n" << E;

    // Unary operators
    SquareMat F = -A;
    std::cout << "Negated A (-A):\n" << F;

    // Pre/post increment and decrement
    ++A;
    std::cout << "++A:\n" << A;

    A++;
    std::cout << "A++:\n" << A;

    --A;
    std::cout << "--A:\n" << A;

    A--;
    std::cout << "A--:\n" << A;

    // Test equality and inequality
    std::cout << "A == B? " << (A == B) << "\n";
    std::cout << "A != B? " << (A != B) << "\n";

    // Identity matrix and transpose
    SquareMat I(3);
    I.identity();
    std::cout << "Identity matrix:\n" << I;

    I.transpose();
    std::cout << "Transpose of identity matrix:\n" << I;

    // Test get and set
    std::cout << "I(0, 0) using get(): " << I.get(0, 0) << "\n";
    I.set(0, 0, 42);
    std::cout << "After set(0, 0, 42):\n" << I;

    // Optional input test (commented)
    /*
    std::cout << "Enter values for a 3x3 matrix (9 numbers):\n";
    std::cin >> A;
    std::cout << "Matrix A after input:\n" << A;
    */

    return 0;
}

