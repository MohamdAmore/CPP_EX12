// mhmd2.ma71@gmail.com
#ifndef SQUARE_MAT_HPP
#define SQUARE_MAT_HPP
#include <ostream>
#include <istream>

namespace mat {

class SquareMat {
private:
    int size_;
    int* data;

    int index(int i, int j) const;

public:
    SquareMat(int size);
    ~SquareMat();
    SquareMat(const SquareMat& other);
    SquareMat& operator=(const SquareMat& other);

    int& operator()(int i, int j);
    int operator()(int i, int j) const;

    SquareMat operator+(const SquareMat& other) const;
    SquareMat operator-(const SquareMat& other) const;
    SquareMat operator*(const SquareMat& other) const;

    SquareMat& operator+=(const SquareMat& other);
    SquareMat& operator-=(const SquareMat& other);
    SquareMat& operator*=(const SquareMat& other);

    bool operator==(const SquareMat& other) const;
    bool operator!=(const SquareMat& other) const;

    SquareMat& operator++();    // Prefix
    SquareMat operator++(int);  // Postfix
    SquareMat& operator--();    // Prefix
    SquareMat operator--(int);  // Postfix

    SquareMat operator-() const;

    int getSize() const;
    int get(int i, int j) const;
    void set(int i, int j, int value);
    void identity();
    void transpose();

    friend std::ostream& operator<<(std::ostream& os, const SquareMat& mat);
friend std::istream& operator>>(std::istream& is, SquareMat& mat);
};

} // namespace mat

#endif // SQUARE_MAT_HPP

